"""
╔══════════════════════════════════════════════════════════════════╗
║          CAMP TRIAGE & RATION OPTIMIZER — ML PIPELINE           ║
║                                                                  ║
║  Predicts for each disaster survivor:                            ║
║    • target_calories_kcal  (XGBoost Regressor)                  ║
║    • water_ration_ml       (XGBoost Regressor)                  ║
║    • medical_priority      (XGBoost Classifier: 0/1/2)          ║
║                                                                  ║
║  Dataset columns used:                                           ║
║    age, weight_kg, height_cm, heart_rate_bpm,                   ║
║    blood_pressure_sys_mmhg, spo2_percent, temperature_c,        ║
║    radiation_mSv, injury_severity, days_without_food,           ║
║    dehydration_level, has_diabetes, has_hypertension,           ║
║    has_respiratory                                               ║
║                                                                  ║
║  Dropped (non-predictive / bias risk):                           ║
║    survivor_id, name                                             ║
╚══════════════════════════════════════════════════════════════════╝

Install deps:
    pip install pandas numpy scikit-learn xgboost joblib
"""

# ── Standard library ───────────────────────────────────────────────
import warnings
warnings.filterwarnings("ignore")

# ── Third-party ────────────────────────────────────────────────────
import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    mean_squared_error, accuracy_score, f1_score,
    classification_report
)
from xgboost import XGBRegressor, XGBClassifier

# ══════════════════════════════════════════════════════════════════
# SECTION 1 — CONFIGURATION
# ══════════════════════════════════════════════════════════════════

CSV_PATH   = "dataset/survivors.csv"   # ← change if needed
SEED       = 42
TEST_SIZE  = 0.20

# Features fed to every model (name & id excluded)
FEATURE_COLS = [
    "age", "weight_kg", "height_cm",
    "heart_rate_bpm", "blood_pressure_sys_mmhg",
    "spo2_percent", "temperature_c",
    "radiation_mSv", "injury_severity",
    "days_without_food", "dehydration_level",
    "has_diabetes", "has_hypertension", "has_respiratory",
]

TARGET_CAL   = "target_calories_kcal"
TARGET_WATER = "water_ration_ml"
TARGET_PRI   = "medical_priority"

PRIORITY_LABELS = {0: "Low", 1: "Medium", 2: "High"}

# ══════════════════════════════════════════════════════════════════
# SECTION 2 — DATA LOADING & PREPROCESSING
# ══════════════════════════════════════════════════════════════════

def load_and_preprocess(csv_path: str) -> tuple:
    """
    Loads the CSV, drops bias-prone columns (name, survivor_id),
    returns feature matrix X and the three target Series.
    """
    print("\n" + "="*60)
    print("  STEP 1 · Loading dataset")
    print("="*60)

    df = pd.read_csv(csv_path)
    print(f"  ✓ Loaded  {df.shape[0]} rows × {df.shape[1]} columns")

    # ── Drop columns that must never influence predictions ─────────
    # 'name'        → alphabetical ordering could introduce spurious
    #                 correlations (fairness concern).
    # 'survivor_id' → arbitrary identifier with no medical meaning.
    bias_cols = [c for c in ["name", "survivor_id"] if c in df.columns]
    df.drop(columns=bias_cols, inplace=True)
    print(f"  ✓ Dropped bias/ID columns: {bias_cols}")

    # ── Verify no nulls ───────────────────────────────────────────
    null_count = df[FEATURE_COLS].isnull().sum().sum()
    if null_count > 0:
        print(f"  ⚠ Found {null_count} nulls — filling with column median")
        df[FEATURE_COLS] = df[FEATURE_COLS].fillna(df[FEATURE_COLS].median())
    else:
        print(f"  ✓ No missing values found")

    X = df[FEATURE_COLS].copy()
    y_cal   = df[TARGET_CAL].copy()
    y_water = df[TARGET_WATER].copy()
    y_pri   = df[TARGET_PRI].copy()

    print(f"\n  Target distributions:")
    print(f"    Calories  → min={y_cal.min()}, max={y_cal.max()}, "
          f"mean={y_cal.mean():.0f}")
    print(f"    Water(ml) → min={y_water.min()}, max={y_water.max()}, "
          f"mean={y_water.mean():.0f}")
    print(f"    Priority  → {dict(y_pri.value_counts().sort_index())}")

    return X, y_cal, y_water, y_pri


# ══════════════════════════════════════════════════════════════════
# SECTION 3 — TRAIN / TEST SPLIT & SCALING
# ══════════════════════════════════════════════════════════════════

def split_and_scale(X, y_cal, y_water, y_pri):
    """
    Splits data 80/20 (stratified on priority class so every
    severity level is represented in both splits).
    Scales features with StandardScaler fitted ONLY on train data
    to prevent data leakage.
    """
    print("\n" + "="*60)
    print("  STEP 2 · Train/Test Split & Feature Scaling")
    print("="*60)

    (X_train, X_test,
     y_cal_train,   y_cal_test,
     y_water_train, y_water_test,
     y_pri_train,   y_pri_test) = train_test_split(
        X, y_cal, y_water, y_pri,
        test_size=TEST_SIZE,
        random_state=SEED,
        stratify=y_pri   # keeps class balance across splits
    )

    print(f"  ✓ Train: {len(X_train)} samples | Test: {len(X_test)} samples")

    # Fit scaler on training data only — avoids leaking test statistics
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)

    print(f"  ✓ StandardScaler fitted on training data")

    return (X_train_scaled, X_test_scaled,
            y_cal_train,   y_cal_test,
            y_water_train, y_water_test,
            y_pri_train,   y_pri_test,
            scaler)


# ══════════════════════════════════════════════════════════════════
# SECTION 4 — MODEL TRAINING
# ══════════════════════════════════════════════════════════════════

def train_models(X_train, y_cal_train, y_water_train, y_pri_train):
    """
    Trains three XGBoost models:
      1. XGBRegressor  → Calories
      2. XGBRegressor  → Water (ml)
      3. XGBClassifier → Medical Priority (0/1/2)
    """
    print("\n" + "="*60)
    print("  STEP 3 · Training XGBoost Models")
    print("="*60)

    # ── Shared XGBoost hyper-parameters ───────────────────────────
    common_params = dict(
        n_estimators    = 300,
        learning_rate   = 0.05,
        max_depth       = 5,
        subsample       = 0.8,
        colsample_bytree= 0.8,
        random_state    = SEED,
        n_jobs          = -1,
    )

    # Model 1 — Calorie Regressor
    print("  Training calorie model ...", end=" ", flush=True)
    cal_model = XGBRegressor(**common_params)
    cal_model.fit(X_train, y_cal_train)
    print("done ✓")

    # Model 2 — Water Regressor
    print("  Training water model    ...", end=" ", flush=True)
    water_model = XGBRegressor(**common_params)
    water_model.fit(X_train, y_water_train)
    print("done ✓")

    # Model 3 — Priority Classifier
    # scale_pos_weight not needed here; we rely on class-balanced
    # splits. For severe imbalance, consider use_label_encoder=False.
    print("  Training priority model ...", end=" ", flush=True)
    pri_model = XGBClassifier(
        **common_params,
        objective    = "multi:softmax",
        num_class    = 3,
        eval_metric  = "mlogloss",
    )
    pri_model.fit(X_train, y_pri_train)
    print("done ✓")

    return cal_model, water_model, pri_model


# ══════════════════════════════════════════════════════════════════
# SECTION 5 — EVALUATION
# ══════════════════════════════════════════════════════════════════

def evaluate_models(cal_model, water_model, pri_model,
                    X_test, y_cal_test, y_water_test, y_pri_test):
    """
    Regression  → RMSE
    Classification → Accuracy, Weighted F1, full report
    """
    print("\n" + "="*60)
    print("  STEP 4 · Model Evaluation")
    print("="*60)

    # ── Calorie RMSE ──────────────────────────────────────────────
    cal_preds  = cal_model.predict(X_test)
    cal_rmse   = np.sqrt(mean_squared_error(y_cal_test, cal_preds))
    cal_pct    = cal_rmse / y_cal_test.mean() * 100
    print(f"\n  [Calories] RMSE = {cal_rmse:.1f} kcal  "
          f"({cal_pct:.1f}% of mean)")

    # ── Water RMSE ────────────────────────────────────────────────
    water_preds = water_model.predict(X_test)
    water_rmse  = np.sqrt(mean_squared_error(y_water_test, water_preds))
    water_pct   = water_rmse / y_water_test.mean() * 100
    print(f"  [Water]    RMSE = {water_rmse:.1f} ml   "
          f"({water_pct:.1f}% of mean)")

    # ── Priority Accuracy & F1 ────────────────────────────────────
    pri_preds  = pri_model.predict(X_test)
    acc        = accuracy_score(y_pri_test, pri_preds)
    f1         = f1_score(y_pri_test, pri_preds, average="weighted")

    print(f"\n  [Priority] Accuracy = {acc:.4f} | "
          f"Weighted F1 = {f1:.4f}")
    print("\n  Classification Report:")
    print(classification_report(
        y_pri_test, pri_preds,
        target_names=["Low (0)", "Medium (1)", "High (2)"]
    ))

    return cal_rmse, water_rmse, acc, f1


# ══════════════════════════════════════════════════════════════════
# SECTION 6 — FEATURE IMPORTANCE
# ══════════════════════════════════════════════════════════════════

def print_feature_importance(cal_model, water_model, pri_model):
    """
    Displays top-10 most influential features for each model,
    ranked by XGBoost's built-in importance scores.
    """
    print("\n" + "="*60)
    print("  STEP 5 · Feature Importance")
    print("="*60)

    models = [
        ("Calories",  cal_model),
        ("Water",     water_model),
        ("Priority",  pri_model),
    ]

    for label, model in models:
        imp = pd.Series(
            model.feature_importances_,
            index=FEATURE_COLS
        ).sort_values(ascending=False)

        print(f"\n  ── {label} model — top 10 features ──")
        for rank, (feat, score) in enumerate(imp.head(10).items(), 1):
            bar = "█" * int(score * 300)
            print(f"    {rank:2}. {feat:<30} {score:.4f}  {bar}")


# ══════════════════════════════════════════════════════════════════
# SECTION 7 — SAVE MODELS
# ══════════════════════════════════════════════════════════════════

def save_models(cal_model, water_model, pri_model, scaler):
    """
    Persists all artefacts to disk using joblib so the demo
    can reload them without retraining.
    """
    print("\n" + "="*60)
    print("  STEP 6 · Saving Models")
    print("="*60)

    joblib.dump(cal_model,   "model_calories.joblib")
    joblib.dump(water_model, "model_water.joblib")
    joblib.dump(pri_model,   "model_priority.joblib")
    joblib.dump(scaler,      "scaler.joblib")

    print("  ✓ model_calories.joblib")
    print("  ✓ model_water.joblib")
    print("  ✓ model_priority.joblib")
    print("  ✓ scaler.joblib")


# ══════════════════════════════════════════════════════════════════
# SECTION 8 — PREDICTION FUNCTION
# ══════════════════════════════════════════════════════════════════

def predict_survivor_needs(input_data: dict,
                           cal_model=None, water_model=None,
                           pri_model=None, scaler=None) -> dict:
    """
    Predicts the 24-hour needs of a single survivor.

    Parameters
    ----------
    input_data : dict
        Keys must match FEATURE_COLS exactly.
        Example:
        {
            "age": 32,
            "weight_kg": 68.0,
            "height_cm": 170.0,
            "heart_rate_bpm": 105,
            "blood_pressure_sys_mmhg": 130,
            "spo2_percent": 92.0,
            "temperature_c": 37.9,
            "radiation_mSv": 350.0,
            "injury_severity": 6,
            "days_without_food": 3,
            "dehydration_level": 2,
            "has_diabetes": 0,
            "has_hypertension": 1,
            "has_respiratory": 0
        }

    Returns
    -------
    dict with keys:
        "Calories_Needed"  (int, kcal)
        "Water_Ration_ml"  (int, ml)
        "Medical_Priority" (str: "Low" | "Medium" | "High")
    """
    # Load from disk if models not passed in (standalone usage)
    if cal_model is None:
        cal_model   = joblib.load("model_calories.joblib")
        water_model = joblib.load("model_water.joblib")
        pri_model   = joblib.load("model_priority.joblib")
        scaler      = joblib.load("scaler.joblib")

    # Build a single-row DataFrame in the correct column order
    row = pd.DataFrame([input_data])[FEATURE_COLS]

    # Apply the same scaling used during training
    row_scaled = scaler.transform(row)

    # Run predictions
    cal   = int(round(cal_model.predict(row_scaled)[0]))
    water = int(round(water_model.predict(row_scaled)[0]))
    pri   = int(pri_model.predict(row_scaled)[0])

    return {
        "Calories_Needed":  cal,
        "Water_Ration_ml":  water,
        "Medical_Priority": PRIORITY_LABELS[pri],
    }


# ══════════════════════════════════════════════════════════════════
# SECTION 9 — FAIRNESS CHECK
# ══════════════════════════════════════════════════════════════════

def fairness_check(csv_path: str, cal_model, water_model,
                   pri_model, scaler):
    """
    Verifies that model predictions are NOT correlated with the
    alphabetical rank of survivor names — ensuring no name-based
    bias was inadvertently introduced through data sorting or
    any upstream process.

    Method: Spearman rank correlation between name-sort-order
    and each prediction. |r| < 0.05 is considered negligible.
    """
    print("\n" + "="*60)
    print("  STEP 7 · Fairness Check — Name-Alphabetical Bias")
    print("="*60)

    from scipy.stats import spearmanr

    df = pd.read_csv(csv_path)
    df["name_rank"] = df["name"].rank(method="dense")  # alphabetical rank

    X_all = df[FEATURE_COLS].copy()
    X_scaled = scaler.transform(X_all)

    preds_cal   = cal_model.predict(X_scaled)
    preds_water = water_model.predict(X_scaled)
    preds_pri   = pri_model.predict(X_scaled)

    targets = {
        "Calories":  preds_cal,
        "Water":     preds_water,
        "Priority":  preds_pri,
    }

    print(f"\n  Spearman ρ between name-alphabetical rank and prediction:")
    all_ok = True
    for label, preds in targets.items():
        rho, pval = spearmanr(df["name_rank"], preds)
        flag = "✓ OK" if abs(rho) < 0.05 else "⚠ BIAS DETECTED"
        print(f"    {label:<10} ρ = {rho:+.4f}  p = {pval:.3f}  {flag}")
        if abs(rho) >= 0.05:
            all_ok = False

    if all_ok:
        print("\n  ✓ No alphabetical name bias detected in any model.")
    else:
        print("\n  ⚠ Investigate bias — check if name leaked into features.")


# ══════════════════════════════════════════════════════════════════
# MAIN PIPELINE
# ══════════════════════════════════════════════════════════════════

def main():
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║        CAMP TRIAGE & RATION OPTIMIZER                ║")
    print("╚══════════════════════════════════════════════════════╝")

    # 1. Load & preprocess
    X, y_cal, y_water, y_pri = load_and_preprocess(CSV_PATH)

    # 2. Split & scale
    (X_train, X_test,
     y_cal_train,   y_cal_test,
     y_water_train, y_water_test,
     y_pri_train,   y_pri_test,
     scaler) = split_and_scale(X, y_cal, y_water, y_pri)

    # 3. Train
    cal_model, water_model, pri_model = train_models(
        X_train, y_cal_train, y_water_train, y_pri_train
    )

    # 4. Evaluate
    evaluate_models(
        cal_model, water_model, pri_model,
        X_test, y_cal_test, y_water_test, y_pri_test
    )

    # 5. Feature importance
    print_feature_importance(cal_model, water_model, pri_model)

    # 6. Save artefacts
    save_models(cal_model, water_model, pri_model, scaler)

    # 7. Fairness check
    fairness_check(CSV_PATH, cal_model, water_model, pri_model, scaler)

    # ── 8. Demo prediction ────────────────────────────────────────
    print("\n" + "="*60)
    print("  STEP 8 · Demo Prediction")
    print("="*60)

    sample = {
        "age":                      32,
        "weight_kg":                68.0,
        "height_cm":                170.0,
        "heart_rate_bpm":           105,
        "blood_pressure_sys_mmhg":  130,
        "spo2_percent":             92.0,
        "temperature_c":            37.9,
        "radiation_mSv":            350.0,
        "injury_severity":          6,
        "days_without_food":        3,
        "dehydration_level":        2,
        "has_diabetes":             0,
        "has_hypertension":         1,
        "has_respiratory":          0,
    }

    result = predict_survivor_needs(
        sample, cal_model, water_model, pri_model, scaler
    )

    print("\n  Input vitals:")
    for k, v in sample.items():
        print(f"    {k:<30} {v}")

    print("\n  ▶ Predicted needs:")
    print(f"    Calories Needed   : {result['Calories_Needed']} kcal")
    print(f"    Water Ration      : {result['Water_Ration_ml']} ml")
    print(f"    Medical Priority  : {result['Medical_Priority']}")

    print("\n╔══════════════════════════════════════════════════════╗")
    print("║  Pipeline complete. Models saved. Ready for demo!    ║")
    print("╚══════════════════════════════════════════════════════╝\n")


if __name__ == "__main__":
    main()
